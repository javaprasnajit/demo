package com.example.demo.repository;

import com.example.demo.model.District;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DistrictRepository extends JpaRepository<District,Integer> {

    Optional<District> findById(Integer id);

    void deleteById(Integer id);

}
