package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Block {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    private String blockName;
    private String blockCode;

    private String gramPanchayatCode;
    private String gramPanchayatName;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name="gramPanchayat_id")
    private List<GramPanchayat> gramPanchayat = new ArrayList<>();


}
