package com.example.demo.service;

import com.example.demo.model.Block;
import com.example.demo.model.Village;
import com.example.demo.repository.BlockRepository;
import com.example.demo.repository.DistrictRepository;
import com.example.demo.repository.GramPanchayatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BlockService {

    @Autowired
    private BlockRepository blockRepository;
    @Autowired
    private GramPanchayatRepository gramPanchayatRepository;

    public void save(Block block) {
        block.setGramPanchayat(gramPanchayatRepository.findBygramPanchayatCode(block.getGramPanchayatCode()));
        block.setGramPanchayat(gramPanchayatRepository.findBygrampanchayatName(block.getGramPanchayatName()));
        blockRepository.save(block);
    }

    public List<Block> listAllBlock() {
        return blockRepository.findAll();

    }

}

