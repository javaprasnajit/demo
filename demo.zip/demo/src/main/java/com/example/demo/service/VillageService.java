package com.example.demo.service;

import com.example.demo.model.Village;
import com.example.demo.repository.VillageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VillageService {

    @Autowired
    private VillageRepository villageRepository;


    public void save(Village village) {
        villageRepository.save(village);
    }
    public List<Village> listAllCircleMaster() {
        return villageRepository.findAll();
    }


}
