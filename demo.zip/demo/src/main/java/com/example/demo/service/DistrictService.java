package com.example.demo.service;

import com.example.demo.model.District;
import com.example.demo.model.Village;
import com.example.demo.repository.BlockRepository;
import com.example.demo.repository.DistrictRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DistrictService {
    @Autowired
    private DistrictRepository districtRepository;

    @Autowired
    private BlockRepository blockRepository;

    public void save(District district) {
       district.setBlock(blockRepository.findByBlockCode(district.getBlockCode()));
       district.setBlock(blockRepository.findByBlockName(district.getBlockName()));
        districtRepository.save(district);
    }

    public List<District> listAllDistrict() {
        return districtRepository.findAll();

    }
}
