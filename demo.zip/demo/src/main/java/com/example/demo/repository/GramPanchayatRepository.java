package com.example.demo.repository;

import com.example.demo.model.GramPanchayat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GramPanchayatRepository extends JpaRepository<GramPanchayat,Integer> {

}
