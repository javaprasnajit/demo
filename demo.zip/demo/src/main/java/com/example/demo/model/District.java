package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class District {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int id;
    private String districtName;
    private String districtCode;
    private String blockCode;
    private String blockName;


    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name="block_id")
    private List<Block> block = new ArrayList<>();
}
