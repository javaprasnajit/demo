package com.example.demo.controller;

import com.example.demo.model.Village;
import com.example.demo.service.VillageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class VillageController {

    @Autowired
    private VillageService villageService;

    @PostMapping("/saveVillage")
    public ResponseEntity<Void> saveVillage(@RequestBody Village village) {
        villageService.save(village);
        return new ResponseEntity<Void>(HttpStatus.CREATED);

    }

    @GetMapping("/getAllVillage")
    public List<Village> getAllCircleDetails() {
        return villageService.listAllCircleMaster();

    }
}
